/*Student Name: : MST.SABIKUN NAHAR MUKTA
        Student ID: :232-35-215
        Batch: 	41st			Section: B*/

package opp_project;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

// Abstract class for an Employee
abstract class Employee implements Serializable {
    private String name;
    private int id;

    public Employee(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public abstract double calculateSalary();

    public abstract String toString();
}

// Full-time Employee class
class FulltimeEmployee extends Employee {
    private double monthlySalary;

    public FulltimeEmployee(String name, int id, double monthlySalary) {
        super(name, id);
        this.monthlySalary = monthlySalary;
    }

    @Override
    public double calculateSalary() {
        return monthlySalary;
    }

    @Override
    public String toString() {
        return "Full-time Employee: Name: " + getName() + ", ID: " + getId() + ", Monthly Salary: $" + monthlySalary;
    }
}

// Part-time Employee class
class PartTime extends Employee {
    private int hoursWorked;
    private double hourRate;

    public PartTime(String name, int id, int hoursWorked, double hourRate) {
        super(name, id);
        this.hoursWorked = hoursWorked;
        this.hourRate = hourRate;
    }

    @Override
    public double calculateSalary() {
        return hoursWorked * hourRate;
    }

    @Override
    public String toString() {
        return "Part-time Employee: Name: " + getName() + ", ID: " + getId() + ", Hours Worked: " + hoursWorked +
                ", Hourly Rate: $" + hourRate + ", Total Salary: $" + calculateSalary();
    }
}

// Utility class for file handling
class FileHandler {
    private static final String FILE_NAME = "employees.txt";

    public static void saveToFile(ArrayList<Employee> employees) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(employees);
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }

    public static ArrayList<Employee> loadFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            return (ArrayList<Employee>) ois.readObject();
        } catch (FileNotFoundException e) {
            return new ArrayList<>(); // Return empty list if file doesn't exist
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading data: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}

// PayrollSystem class
class PayrollSystem {
    private ArrayList<Employee> employeeArrayList;

    public PayrollSystem() {
        employeeArrayList = FileHandler.loadFromFile(); // Load employees from file
    }

    public void addEmployee(Employee employee) {
        employeeArrayList.add(employee);
        FileHandler.saveToFile(employeeArrayList); // Save changes to file
    }

    public void removeEmployee(int id) {
        Employee employeeToRemove = null;
        for (Employee employee : employeeArrayList) {
            if (employee.getId() == id) {
                employeeToRemove = employee;
                break;
            }
        }
        if (employeeToRemove != null) {
            employeeArrayList.remove(employeeToRemove);
            FileHandler.saveToFile(employeeArrayList); // Save changes to file
            System.out.println("Employee removed successfully.");
        } else {
            System.out.println("Employee with ID " + id + " not found.");
        }
    }

    public void displayEmployees() {
        if (employeeArrayList.isEmpty()) {
            System.out.println("No employees to display.");
        } else {
            for (Employee employee : employeeArrayList) {
                System.out.println(employee);
            }
        }
    }
}

// Main class
public class PayrollmanagementSystem {
    public static void main(String[] args) {
        PayrollSystem payrollSystem = new PayrollSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Add Full-time Employee");
            System.out.println("2. Add Part-time Employee");
            System.out.println("3. Display Employees");
            System.out.println("4. Remove Employee");
            System.out.println("5. Exit");

            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.println("Enter Full-time Employee details - Name, ID, Monthly Salary:");
                        String fullName = scanner.nextLine();
                        int empId = scanner.nextInt();
                        double monthlySalary = scanner.nextDouble();
                        scanner.nextLine(); // Consume newline
                        FulltimeEmployee fulltimeEmployee = new FulltimeEmployee(fullName, empId, monthlySalary);
                        payrollSystem.addEmployee(fulltimeEmployee);
                        break;
                    case 2:
                        System.out.println("Enter Part-time Employee details - Name, ID, Hours Worked, Hourly Rate:");
                        fullName = scanner.nextLine();
                        empId = scanner.nextInt();
                        int hoursWorked = scanner.nextInt();
                        double hourlyRate = scanner.nextDouble();
                        scanner.nextLine(); // Consume newline
                        PartTime partTimeEmployee = new PartTime(fullName, empId, hoursWorked, hourlyRate);
                        payrollSystem.addEmployee(partTimeEmployee);
                        break;
                    case 3:
                        payrollSystem.displayEmployees();
                        break;
                    case 4:
                        System.out.println("Enter the ID of the employee to remove:");
                        int idToRemove = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        payrollSystem.removeEmployee(idToRemove);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        scanner.close();
                        System.exit(0);
                    default:
                        System.out.println("Invalid option. Please choose again.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please try again.");
                scanner.nextLine(); // Clear invalid input
            }
        }
    }
}
